"""
DOA for ReSpeaker 6 mic array
"""

# It's the same geometry as the ReSpeaker Core v2
from .doa_respeaker_v2_6mic_array import DOA
